
class Treevisualizer {

    constructor(){

        this.speed=0.01;
        this.dir=1;
        this.anim=true;

        this.visSteps=[];
        this.visStepsNumber=-1;
        this.actualStep=-1;
        this.actualStepElement=0;



        this.stepanim=false;


        



        this.tree=new Tree;
        this.vistree;
        this.visSubTree;
        this.treeIsSet=false;
        this.CloneNotSet=false;


        this.pg = createGraphics(windowWidth, 3*windowHeight/4);
        
        


        
    }


    setAnimation(){

        if(this.anim){
            this.anim=false;
        }
        else{
            this.anim=true;
        }

    }


    addElement(val){

        val=parseInt(val)

        if(isNaN(val)){
          console.log(NaN);
            return 0;
        }
    


        if(this.actualStep<this.visStepsNumber){

            if(this.actualStep==-1){
                this.tree=new Tree;
                

            }
            else{
                
                this.tree=this.visSteps[this.actualStep]["NewTree"].Clone();
                this.tree.CordinatEquals();
                
            }
            
        }





        this.addSteps(this.tree.addValue(val));

    }



    setAnimationSpeed(val){

        this.speed=val;

    }


    addSteps(data){

        if(data.length==0){
            return 0;
        }

        

        
        this.visStepsNumber= this.actualStep+1;
        this.actualStep=this.visStepsNumber;
        this.actualStepElement=0;
        
        this.visSteps[this.visStepsNumber]=data;

        this.ChangeTree();
    

      

    }

    stepForward(){
        
        if(this.visStepsNumber==-1){
           
            return 0;
  
        }

       
        this.anim=true;

        if(this.actualStep==-1){
            this.actualStep=0;
            return 0;
        }


      
      
    

        
        if(this.actualStepElement+1>=this.visSteps[this.actualStep]["List"].length){


            
            if(this.actualStep+1<=this.visStepsNumber) {

                this.actualStep=this.actualStep+1;
                this.actualStepElement=0;
                this.ChangeTree();
            }
          
       
           

        }
        else{

            this.actualStepElement=1+this.actualStepElement;
            this.ChangeTree();


            
        }

        

      
       

    }

    stepForwardSkip(){
        
        if(this.visStepsNumber==-1){
           
            return 0;
        }

        
        this.anim=true;

        if(this.actualStep==-1){
            this.actualStep=0;
            return 0;
        }

      
      
    
        if(this.actualStepElement+1==this.visSteps[this.actualStep]["List"].length){
            this.stepForward();
        }
        else{
            this.actualStepElement=this.visSteps[this.actualStep]["List"].length-1;
            this.ChangeTree();
        }
        
   
      
       

    }
      
    
    stepBackward(){

        
        if(this.visStepsNumber==-1){
            return 0;
        }

        //this.treeIsSet=true;
        this.anim=false;
        
        if(this.actualStepElement-1<0){
            
            if(this.actualStep-1>-1) {

                this.actualStep= this.actualStep-1;
                this.actualStepElement=this.visSteps[this.actualStep]["List"].length-1;
                //this.treeIsSet=false;
                this.ChangeTree();
            }
            else if(this.actualStep-1==-1){
                this.actualStep= this.actualStep-1;
                this.actualStepElement=0;
                
            }


        }
        else{
           
            
            this.actualStepElement=this.actualStepElement-1;
            this.ChangeTree();

        }

        
        

    }


    stepBackwardSkip(){

        

        
        if(this.visStepsNumber==-1){
            return 0;
        }

        this.anim=false;
        this.treeIsSet=false;
        
        if(this.actualStepElement==0){
            
         this.stepBackward();

        }
        else{
            this.actualStepElement=0;
            this.ChangeTree();
        }

       
        

    }


    



    drawTree() {
    


        if(this.CloneNotSet) {
            console.log("kihagy");
            return 0;
        }
       

 
        


  


        if(this.visStepsNumber==-1 ||this.actualStep==-1) return 0;


        
        
        
         
        
        this.visSubTree=this.vistree;
        
        var actual=this.visSteps[this.actualStep];
        var actualNewTree=actual["NewTree"];
        var actualOldTree=actual["OldTree"];
        var actualListelement=actual["List"][this.actualStepElement];


        switch (actualListelement.command) {
            case "Add":
                   
                //kirajzolás

                
                var x=actualListelement.visElement1.x;
                var y=actualListelement.visElement1.y;
                var val=actualListelement.visElement1.value;
                var color=actualListelement.visElement2.color;


                
                
                var value=actualListelement.visElement2.value;
                
                 
                fill(255); 
                textAlign(LEFT,CENTER);
                textSize(20);
                text(actualListelement.visElement3,90, 3*windowHeight/4-100);  




                if(val<value){
                    this.drawNode(x+50,y,value,color);
                }
                else{
                    
                    this.drawNode(x-50,y,value,color);
                }

              break;
           
            case "Animation":
                

                fill(255); 
                textAlign(LEFT,CENTER);
                textSize(20);
                text(actualListelement.visElement3,90,  3*windowHeight/4-100);  

                this.stepanim=true;
                
              break;
            case "AddAnimation":
              
                fill(255); 
                textAlign(LEFT,CENTER);
                textSize(20);

                
                this.visSubTree=actualListelement.visElement1.Clone();


                
                text(actualListelement.visElement3,90,  3*windowHeight/4-100);  

                this.stepanim=true;


              break;
            case 4:
              day = "";
              break;
            case 5:
              day = "";
              break;
            case 6:
              day = "";
          }

      
         
        
          if(this.vistree.root!=this.vistree.nil)  this.PostOrder(this.vistree.root,this.vistree.nil,this.vistree.nil);  
        

    }



    drawNode(x,y,value,color="piros"){

        noStroke();
        fill(0,0,0);
        if(color=="Red"){
            fill(255,2,2);

        }

        
        ellipse( x, y, 40, 40);
        fill(255); 
        textAlign(CENTER,CENTER);
        textSize(20);
        text(value,x, y);  

    }


    PostOrder=function(n,nil,stopnode){
        
        if(n.left!= nil && n.left.value!= stopnode.value ){
            this.PostOrder(n.left,nil,stopnode);
        
        }

        if(n.right!=nil && n.right.value!= stopnode.value  ){
            this.PostOrder(n.right,nil,stopnode);
        
        }

        
        n.drawx=n.x;
        n.drawy=n.y;
     
        stroke(255);

        if(this.stepanim){

            this.MoveNode(n);
        
        }
             
          
           
            if(n.parent!=nil){
                stroke(255);
                line(n.parent.drawx, n.parent.drawy, n.drawx, n.drawy);
            }
            
        
            this.drawNode(n.drawx,n.drawy,n.value,n.color);
    

    }

    MoveNode(n){

 
        if(this.anim){
            n.drawx = n.x*n.lambda + n.newx*(1-n.lambda);
            n.drawy = n.y*n.lambda + n.newy*(1-n.lambda);
    
                
            n.lambda = n.lambda - this.speed;
            
            if( n.lambda < 0){
                n.lambda=1;
                n.x=n.newx;
                n.y=n.newy;
                  
            }
        }
        else{
            n.lambda=1;
            n.x=n.newx;
            n.y=n.newy;
            n.drawx=n.newx;
            n.drawy=n.newy;
        }


    }


    ChangeTree(){

        if(this.actualStepElement==0){
            this.setTree(this.visSteps[this.actualStep]["OldTree"]);

        }
        else if(this.actualStepElement==this.visSteps[this.actualStep]["List"].length-1){
            this.setTree(this.visSteps[this.actualStep]["NewTree"]);
        }
        else if(this.visSteps[this.actualStep]["List"][this.actualStepElement].command == 'Add'){
            this.setTree(this.visSteps[this.actualStep]["OldTree"]);
        }
        else if(this.visSteps[this.actualStep]["List"][this.actualStepElement].command == 'Animation'){
            this.setTree(this.visSteps[this.actualStep]["List"].visElement1)
        }
        else if(this.visSteps[this.actualStep]["List"][this.actualStepElement+1].command == 'AddAnimation' && this.visSteps[this.actualStep]["List"][this.actualStepElement].command != 'Animation'){
            this.setTree(this.visSteps[this.actualStep]["OldTree"]);

        }
     

    }

    setTree(t){

        
            
            
            this.vistree=t.Clone();
            
            

    }




}