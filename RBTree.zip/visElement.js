

class visElement{

    constructor(command,visel1,visel2,visel3,visel4,visel5,visel6){
        this.command=command;
        this.visElement1=visel1;
        this.visElement2=visel2;
        this.visElement3=visel3;
        this.visElement4=visel4;
        this.visElement5=visel5;
        this.visElement6=visel6;

    }


}